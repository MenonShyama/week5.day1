package week5.day1;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		XSSFWorkbook wb =new XSSFWorkbook("./data/ServiceNow.xlsx");
		XSSFSheet sheetName = wb.getSheet("edit_data");
		XSSFRow row = sheetName.getRow(0);
		XSSFCell cell = row.getCell(0);
		String stringCellValue = cell.getStringCellValue();
System.out.println(stringCellValue);
wb.close();
	}

}
