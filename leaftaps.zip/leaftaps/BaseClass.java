package week2.day2;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class BaseClass {
  
	public ChromeDriver driver;
	public String fileName; 
@Parameters({"url","firstName","lastName"})
  @BeforeMethod
  
  public void beforeMethod(String url,String firstName,String lastName) {
	  WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		driver.findElement(By.id("username")).sendKeys(firstName);
		driver.findElement(By.id("password")).sendKeys(lastName);
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
  }
@DataProvider(name="fc")
public String[][] sendData() throws IOException{
	return FileRead.readfile(fileName);
}

  @AfterMethod
  public void afterMethod() {
	  driver.close();
  }


}
