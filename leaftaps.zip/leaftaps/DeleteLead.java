package week2.day2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DeleteLead extends BaseClass{
	
	//Pre-requisite required
	//should have a record with the number 9645454577
	
	@Test(enabled=true,priority=5)

	public void deleteLead() throws InterruptedException {
		
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(5000);
		//driver.findElement(By.xpath("//span[text()='Phone']")).click();
		// driver.findElement(By.xpath("//input[@name='phoneAreaCode']")).sendKeys("91");
		driver.findElement(By.xpath("(//div[@class='x-tab-panel-bwrap']//div[@class='x-form-element']/input)[2]")).sendKeys("shyama");
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[contains(@class,'x-grid3-cell-inner')]/a[@class='linktext']"))
				.getAttribute("value");

		WebElement output = driver
				.findElement(By.xpath("//div[contains(@class,'x-grid3-cell-inner')]/a[@class='linktext']"));
		String leadId = output.getText();

		System.out.println(leadId);
		output.click();
		driver.findElement(By.xpath("//a[text()='Delete']")).click();
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys("9677699819");
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		WebElement message = driver.findElement(By.xpath("//div[@class='x-paging-info']"));
		String outputMessage = message.getText();
		System.out.println(outputMessage);
		System.out.println("deleted");

		// driver.findElement(By.xpath("//input[@name='id']")).);

	}

}
