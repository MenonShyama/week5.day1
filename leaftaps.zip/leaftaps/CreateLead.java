package week2.day2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateLead extends BaseClass{
	
	@BeforeClass
	public void setup()
	{
		fileName="CreateLead";
	}
	@Test(dataProvider="fc")
	
	public void createLead(String cName,String firstName,String lastName) {
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("Info");
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("shyama");
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("menon");
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys("9677699819");;
		WebElement dd = driver.findElement(By.id("createLeadForm_dataSourceId"));
		Select dropdown=new Select(dd);
		dropdown.selectByVisibleText("Employee");
		WebElement marketDropdown = driver.findElement(By.xpath("//select[@name='marketingCampaignId']"));
		Select marketCampignDropdown=new Select(marketDropdown);
		marketCampignDropdown.selectByValue("9001");
		WebElement ownershipDropdown = driver.findElement(By.xpath("//select[@name='ownershipEnumId']"));
		Select ownershipEnumDropdown=new Select(ownershipDropdown);
		ownershipEnumDropdown.selectByIndex(5);
		WebElement countryDropdown = driver.findElement(By.xpath("//select[@name='generalCountryGeoId']"));
		Select countryEnumDropdown=new Select(countryDropdown);
		countryEnumDropdown.selectByVisibleText("India");
		driver.findElement(By.name("submitButton")).click();
		System.out.println(driver.getTitle());
		System.out.println("created");
	}		
	//	@DataProvider(name="fc")
//		public String[][] sendData() {
//			// TODO Auto-generated method stub
////			String[][] data=new String[2][3];
////			data[0][0]="TestLeaf";
//			return data;
//		

}

	
	


